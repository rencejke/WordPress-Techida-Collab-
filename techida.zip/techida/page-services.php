<?php get_header(); ?>

<!-- BANNER STARTS -->
<section class="banner" data-aos="fade-up" data-aos-delay="100">
      <div class="container">
        <div class="banner__wrapper">
          <div class="bannernav">
            <a href=""><?php echo get_field('banner_a1')?></a>
            <span>/</span>
            <a href=""><?php echo get_field('banner_a2')?></a>
          </div>
          <h1><?php echo get_field('banner_h1')?></h1>
          <p><?php echo get_field('banner_p')?></p>
        </div>
      </div>
    </section>
    <!-- BANNER ENDS -->

<!-- SERVICES STARTS -->
<section class="services">
        <div class="container">
          <div class="services__title">
            <h4 data-aos="fade-up"><?php echo get_field('section_h4') ?></h4>
            <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('section_h2') ?></h2>
            <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('section_paragraph') ?></p>
          </div>
          <div class="services__wrapper">
            <!-- services 1 -->
            <?php 
            if(have_rows('services_card')) : ?>
            <?php while(have_rows('services_card')) : the_row(); ?>
            <div class="services__card" data-aos="fade-right" data-aos-delay="250">
              <i class="<?php echo get_sub_field('servicesicon_type') ?> <?php echo get_sub_field('services_icon') ?>"></i>
              <h3><?php echo get_sub_field('services_heading') ?></h3>
              <p><?php echo get_sub_field('services_paragraph') ?></p>
              <a href=""><?php echo get_sub_field('services_btn') ?> <i class="fa-solid <?php echo get_sub_field('services_btn_icon') ?>"></i></a>
            </div>
            <?php endwhile;
            else:
                echo "No more services";
            endif;
            ?>
        </div>
      </section>
      <!-- SERVICES ENDS -->

      <!-- FAQ STARTS -->
<section class="faq">
    <div class="container">
      <div class="faq__title">
        <h4 data-aos="fade-up"><?php echo get_field('faq_h4') ?></h4>
        <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('faq_h2') ?></h2>
        <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('faq_p') ?></p>
      </div>
      <div class="faq__wrapper">
        
        <div class="faq__image" data-aos="fade-right" data-aos-delay="200">
          <img src="<?php echo get_field('faq_img') ?>" alt="">
        </div>
        <div class="faq__question">
          <!-- question 1 -->
          
          <?php
          if(have_rows('faq_cards')) : ?>
                <?php while(have_rows('faq_cards')) : the_row(); ?>
          <div class="faq__cards" data-aos="fade-up" data-aos-delay="250">
            <div class="question">
              <h5><?php echo get_sub_field('faqs_question') ?><i class="fa-solid <?php echo get_sub_field('faq_icons') ?>"></i></h5>  
              <div class="contents">
                <p><?php echo get_sub_field('faqs_question_p') ?></p> 
              </div> 
            </div>
          </div>
          <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?>    
        </div>
      </div>
    </div>
   </section>
   <!-- FAQ ENDS -->

   <!-- CONTACTS STARTS -->
   <section class="contact">
    <div class="container">
            <div class="contact__title">
                <h4 data-aos="fade-up"><?php echo get_field('contacts_h4') ?></h4>
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('contacts_h2') ?></h2>
                <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('contacts_p') ?></p>
            </div>
        <div class="contact__wrapper">
            <div class="contact__left">
                <h3 data-aos="fade-right" data-aos-delay="200"><?php echo get_field('contacts_info_title') ?></h3>


                <ul>
                <?php
                    if(have_rows('contacts_info_data')) : ?>
                <?php while(have_rows('contacts_info_data')) : the_row(); ?>
                    <li class="flex gap-6" data-aos="fade-right" data-aos-delay="250">
                        <i class="<?php echo get_sub_field('contactsicon_style') ?> <?php echo get_sub_field('contacts_icon') ?>"></i>
                        <p><?php echo get_sub_field('contacts_info') ?></p>
                    </li>
                    <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?>    
                </ul>
            </div>
            <div class="contact__form">
                <ul>
                    <li data-aos="fade-right" data-aos-delay="200">
                        <input type="text" placeholder="Name">
                    </li>
                    <li data-aos="fade-left" data-aos-delay="200">
                        <input type="text" placeholder="Subject">
                    </li>
                </ul>
                <ul data-aos="fade-up" data-aos-delay="250">
                    <input type="text" placeholder="Email">
                </ul>
                <ul data-aos="fade-up" data-aos-delay="300">
                    <textarea name="" id="" cols="30" rows="10" placeholder="Message"></textarea>
                </ul>
                <div class="contact__btn" data-aos="fade-up" data-aos-delay="350">
                    <a class="btn bg--vera" href="">Send Now</a>
                </div>
            </div>
        </div>
    </div>
   </section>
   <!-- CONTACTS ENDS -->

   <!-- MAP STARTS -->
   <section class="map">
    <div class="container">
      <div class="map__wrapper">
        <iframe class="contact-map" data-aos="fade-up" data-aos-delay="450" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.9050207912896!2d-0.14675028449633118!3d51.514958479636384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761ad554c335c1%3A0xda2164b934c67c1a!2sOxford+St%2C+London%2C+UK!5e0!3m2!1sen!2sro!4v1485889312335" allowfullscreen=""></iframe>
      </div>  
    </div>
   </section>
   <!-- MAP ENDS -->

<?php get_footer(); ?>