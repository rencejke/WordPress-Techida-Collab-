
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techida - Business Services</title>
    <!-- <link rel="stylesheet" href="/src/output.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css" integrity="sha512-vebUliqxrVkBy3gucMhClmyQP9On/HAWQdKDXRaAlb/FKuTbxkjPKUyqVOxAcGwFDka79eTF+YXwfke1h3/wfg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css"/> -->
    <?php wp_head() ?>
</head>
<body class=" bg-primary dark:bg-darkmode transition-all ease-out duration-300">
    
    <div id="progressTop">
        <span id="progressTop-value">&#x1F815</span>
    </div>

    <div class="wrapper pb-[3rem] ">
            <header class="header ">
            <div class="container ">
                <div class="header__wrapper ">
                <?php the_custom_logo();?>
                    

                    <div class="header__navd">
                    <?php wp_nav_menu(array(
                        'theme_location' => 'header_menu',
                    ))?>
                    </div>
                    <!-- <ul class="header__navd md:invisible lg:visible">
                   
                        <li><a href="./home.html">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="./services.html">Services</a></li>
                        <li><a href="#">Pages</a></li>
                        <li><a href="#">Portfolio</a></li>
                        <li><a href="./blog.html">Blog</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul> -->
                    <div class="header__action">
                       
                        <ul class="header__navm">
                        <?php wp_nav_menu(array(
                        'theme_location' => 'header__mobileMenu1',
                    ))?>
                            <li>
                                <div class="pages__drpdwn ">
                                    <div class="question">
                                      <a>Pages <i class="fa-solid fa-chevron-down"></i></a>  
                                      <ul class="contents">
                                        <li><a href="<?php echo get_field('home_url') ?>">Home</a></li>
                                        <li><a href="<?php echo get_field('services_url') ?>">Services</a></li>
                                        <li><a href="<?php echo get_field('blog_url') ?>">Blogs</a></li>
                                      </ul>
                                    </div>
                                  </div>
                            </li>
                            <?php wp_nav_menu(array(
                        'theme_location' => 'header__mobileMenu2',
                    ))?>
                        </ul>
                        <div class="header__action__btn block lg:hidden">
                            <button class="btn bg--verb">Join now</button>
                            <i id="toggledark" onclick="functionToggle(this)" class="fa-solid fa-moon" ></i>
                        </div>
                    </div>
                    <div class="header__action__btn hidden lg:block">
                        <button class="btn bg--verb">Join now</button>
                        <i id="toggle"onclick="functionToggle(this)" class="fa-solid fa-moon"></i>
                    </div>

                    <div class="burger__menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </header>