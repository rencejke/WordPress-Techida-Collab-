<footer class="footer">
    <div class="container">
      <div class="footer__wrapper">
        <div class="socials">
          <img src="<?php echo get_field('footer_logo') ?>" alt="">
          <p><?php echo get_field('footer_paragraph') ?></p>
          <h6><?php echo get_field('socialmedia_title') ?></h6>   
          <div class="media">
          <?php
          if(have_rows('social_media')) : ?>
                <?php while(have_rows('social_media')) : the_row(); ?>
            <i class="fa-brands <?php echo get_sub_field('socialmedia_icon') ?>"></i>
            <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?> 
          </div>
        </div>
        <div class="site">
          <h6>Site Map</h6>
          <?php wp_nav_menu(array(
                        'theme_location' => 'footer__menu',
                    ))?>
        </div>
        <div class="follow">
          <h6> <?php echo get_field('socialmedia_title') ?></h6>

          
          <ul class="socialMedia">  
          <?php
                    if(have_rows('social_media')) : ?>
                <?php while(have_rows('social_media')) : the_row(); ?>
            <li><a href=""><i class="fa-solid <?php echo get_sub_field('socialmedia_text_icon') ?>"></i><?php echo get_sub_field('socialmedia_text') ?></a></li>
            <?php endwhile;
                else:
                    echo "No more";
                endif;
                ?>    
          </ul>
        </div>
        <div class="servicesfooter">
          <h6>Our Services</h6>
          <ul class="listServices">
          <?php
                    if(have_rows('footer_services')) : ?>
                <?php while(have_rows('footer_services')) : the_row(); ?>
            <li><a href=""><i class="fa-solid <?php echo get_sub_field('footerservices_icon') ?>"></i><?php echo get_sub_field('footerservices_text') ?></a></li>
            <?php endwhile;
                else:
                    echo "No more";
                endif;
                ?>    
          </ul>
        </div>
      </div>
    </div>
   </footer>

   <footer class="bottomFooter">
      <div class="container">
        <div class="bottomFooter__wrapper">
          <p>&copy; <?php echo get_field('footerunder_p') ?> <a href=""><?php echo get_field('footerunder_a1') ?></a></p>
        <div class="terms">
          <a href=""><?php echo get_field('footerunder_a2') ?></a>
          <a href=""><?php echo get_field('footerunder_a3') ?></a>
        </div>
        </div>
      </div>
    </footer>
    <?php wp_footer() ?>

    <script>
        var slider = tns({
        container: '.testimonials__slider',
        items: 1,
        slideBy: 1,
        autoplay: true,
        controls: false,
        mouseDrag: true,
        navPosition: "bottom",
        autoplayButtonOutput: false,
    
        responsive: {
          414: {
            gutter: 20,
            items: 1
          },
          700: {
            gutter: 20,
            items: 2
          },
          900: {
            items: 3
          }
        }
        
      });
       </script>
       
   <script>
    var slider = tns({
    container: '.logo__slider__wrapper',
    items: 1,
    slideBy: 1,
    autoplay: true,
    controls: false,
    mouseDrag: true,
    autoplayButtonOutput: false,
    nav: false,
    speed: 200,

    responsive: {
      414: {
        gutter: 20,
        items: 2
      },
      700: {
        gutter: 30,
        items: 3
      },
      900: {
        items: 5
      }
    }
    
  });
   </script>

</body>



   <!-- particle js -->
    <script src="./js/particle/particles.js"></script>
    <script src="./js/particle/app.js"></script>
    <script src="./js/script.js"></script>

    <!-- counter js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js" integrity="sha256-jDnOKIOq2KNsQZTcBTEnsp76FnfMEttF6AV2DF2fFNE=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js" integrity="sha256-JtQPj/3xub8oapVMaIijPNoM0DHoAtgh/gwFYuN5rik=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
    <script>
        $('.count').counterUp({
            delay: 1,
            time:300
        })
    </script>

</body>
</html>