<?php get_header(); ?>

<div  id="particles-js"></div>
        
        <!-- HOME BANNER STARTS -->
    <section class="homebanner">
            <div class="container">
                <div class="homebanner__wrapper">
                    <div class="homebanner__text">
                    <h1 data-aos="fade-up" data-aos-delay="150"><?php echo get_field('homebanner_header') ?> <span class="text-secondary"><?php echo get_field('homebanner_span') ?></span> For Your Success</h1>
                        <p data-aos="fade-up" data-aos-delay="200">
                        <?php echo get_field('homebanner_paragraph') ?>
                        </p>
                            <button data-aos="fade-up" data-aos-delay="250" class="btn bg--verb" ><?php echo get_field('homebanner_btn') ?></button>
                    </div>
                    <div class="homebanner__img">
                        <img data-aos="fade-right" data-aos-delay="100"src="<?php echo get_field('homebanner_image') ?>" alt="">
                    </div>
                </div>
            </div>
        </section>
         <!-- HOME BANNER ENDS -->
        </div>


           <!-- SERVICES STARTS -->
    <section class="services">
        <div class="container">
          <div class="services__title">
            <h4 data-aos="fade-up"><?php echo get_field('section_h4') ?></h4>
            <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('section_h2') ?></h2>
            <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('section_paragraph') ?></p>
          </div>
          <div class="services__wrapper">
            <!-- services 1 -->
            <?php 
            if(have_rows('services_card')) : ?>
            <?php while(have_rows('services_card')) : the_row(); ?>
            <div class="services__card" data-aos="fade-right" data-aos-delay="250">
              <i class="<?php echo get_sub_field('servicesicon_type') ?> <?php echo get_sub_field('services_icon') ?>"></i>
              <h3><?php echo get_sub_field('services_heading') ?></h3>
              <p><?php echo get_sub_field('services_paragraph') ?></p>
              <a href=""><?php echo get_sub_field('services_btn') ?> <i class="fa-solid <?php echo get_sub_field('services_btn_icon') ?>"></i></a>
            </div>
            <?php endwhile;
            else:
                echo "No more services";
            endif;
            ?>
        </div>
      </section>
      <!-- SERVICES ENDS -->

    <!-- ABOUT US STARTS -->
    <section class="aboutUs">
        <div class="container">
            <div class="aboutUs__wrapper">
                
                <div class="aboutUs__item mb-4">
                    <div class="aboutUs__text">
                        <h4 data-aos="fade-up" data-aos-delay="200"><?php echo get_field('about1_h4') ?></h4>
                        <h2 data-aos="fade-up" data-aos-delay="250"><?php echo get_field('about1_h2') ?> <span class="text-secondary">2015</span></h2>
                        <p data-aos="fade-up" data-aos-delay="300" class="pb-[.7rem]">
                        <?php echo get_field('about1_p') ?>
                        </p>
                            <button data-aos="fade-up" data-aos-delay="350" class="btn bg--verb"><?php echo get_field('about1_btn') ?></button>
                    </div>

                    <div class="aboutUs__image">
                        <img data-aos="fade-left" data-aos-delay="100" src="<?php echo get_field('about1_image') ?>" alt="">
                    </div>
                
                </div>

                <div class="aboutUs__item mb-[4rem]">
                    <div class="aboutUs__image">
                        <img data-aos="fade-right" data-aos-delay="100" src="<?php echo get_field('about2_image') ?>" alt="">
                    </div>
                    <div class="aboutUs__text">
                        <h2 data-aos="fade-up" data-aos-delay="200" class="font-bold"><?php echo get_field('about2_h2') ?> <span class="text-secondary"><?php echo get_field('about2_span') ?></span></h2>
                        <p data-aos="fade-up" data-aos-delay="250">
                        <?php echo get_field('about2_p') ?>
                        </p>
                        
                            <div class="aboutUs__services__wrapper mt-[1rem]">
                            <?php 
                                if(have_rows('about_card')) : ?>
                                <?php while(have_rows('about_card')) : the_row(); ?>

                                <!-- services 1 -->
                                <div class="aboutUs__services__card" data-aos="fade-up" data-aos-delay="300">
                                <i class="fa-solid <?php echo get_sub_field('about_icon') ?>"></i>
                                <p data-aos="fade-up" data-aos-delay="250"><?php echo get_sub_field('about_p') ?><p><p>
                                </div>
                                <?php endwhile;
                                else:
                                    echo "No more services";
                                endif;
                                ?>
                            </div>
                    </div>
                </div>

                <div class="aboutUs__item">
                    <div class="aboutUs__text">
                        <h2  data-aos="fade-up" data-aos-delay="200"><?php echo get_field('about3_h2') ?> <span class="text-secondary"><?php echo get_field('about3_span') ?></span></h2>
                        <p  data-aos="fade-up" data-aos-delay="250" class="pt-3">
                        <?php echo get_field('about3_p') ?>
                        </p>

                        <div class="progress__container">
                        <?php
                        $experience = New WP_Query(array(
                                'post_type' => 'experience',
                                'posts_per_page' => 3,
                                'paged' =>  get_query_var('paged', 2) 
                        ))
                        ?>
                        <?php if( $experience->have_posts()) : while( $experience->have_posts()) : $experience->the_post(); ?>
                                        
                            <div class="aboutUs__progress" data-aos="fade-up" data-aos-delay="300">
                                <span class="aboutUs__progress__title"><?php the_title() ?></span>

                                <?php the_content() ?>
                            </div>
                            <?php endwhile;
                            else:
                                echo "No more";
                            endif;
                            wp_reset_postdata();
                            ?>
                        </div>
                    </div>

                    <div class="aboutUs__image">
                        <img data-aos="fade-left" data-aos-delay="100" src="<?php echo get_field('about3_image') ?>" alt="">
                    </div> 
                </div>
            </div>
        </div>
    </section>
    <!-- ABOUT US ENDS -->

    <!-- COUNTER STARTS -->
    <section class="counter" data-aos="fade-up" data-aos-delay="100">
        <div class="container">
            <div class="counter__wrapper">

            <?php 
            if(have_rows('counter_card')) : ?>
            <?php while(have_rows('counter_card')) : the_row(); ?>
                <!-- item 1 -->
                <div class="counter__item">
                    <h1 class="count"><?php echo get_sub_field('counter_number') ?></h1>
                    <p><?php echo get_sub_field('counter_text') ?></p>
                </div>
                <?php endwhile;
            else:
                echo "No more services";
            endif;
            ?>
            </div>
        </div>
       </section>
       <!-- COUNTER ENDS -->
    
      <!-- CHOOSE STARTS -->
       <section class="choose">
        <div class="container">
            <div class="choose__wrapper">
                <div class="choose__text">
                    <h4><?php echo get_field('choose_h4') ?></h4>
                    <h2><?php echo get_field('choose_h2') ?></h2>
                    <p><?php echo get_field('choose_paragraph') ?></p>
                </div>
                
                <div class="choose__card">

                <?php 
                if(have_rows('choose_card')) : ?>
                 <?php while(have_rows('choose_card')) : the_row(); ?>
                <div class="choose__card__item">
                <h4><?php echo get_sub_field('choose_card_h4') ?></h4>
                <h3><?php echo get_sub_field('choose_card_h6') ?></h3>
                <p><?php echo get_sub_field('choose_card_p') ?></p>
                </div>
                <?php endwhile;
            else:
                echo "No more services";
            endif;
            ?>
            </div>
            </div>
        </div>
       </section>
       <!-- CHOOSE ENDS -->

       <section class="portfolio">
             <div class="container">
            
                <h4 data-aos="fade-up">Portfolio</h4>
                <h2 data-aos="fade-up" data-aos-delay="100">Our Portfolio</h2>
            <div class="wrapper">
                 <div class="portfolio__tab">   
                <!-- portfolio button navs -->
                <?php 
                if(have_rows('portfolio_tabs')) : ?>
                 <?php while(have_rows('portfolio_tabs')) : the_row(); ?>
                <div class="portfolio__navs" data-aos="fade-up" data-aos-delay="150">

                <button class="<?php echo get_sub_field('portfolio_nav_status')?>" data-name="<?php echo get_sub_field('portfolio_nav_data')?>"><?php echo get_sub_field('portfolio_nav_text')?></button>
                </div>
                <?php endwhile;
            else:
                echo "No more services";
            endif;
            ?>
            </div>
                     <!-- portfolio Images -->
              <div class="portfolio__images" data-aos="fade-up" data-aos-delay="150">
            <?php
            if(have_rows('portfolio_image_card')) : ?>
            <?php while(have_rows('portfolio_image_card')) : the_row(); ?>
                <div class="portfolio__images__card" data-name="<?php echo get_sub_field('portfolio_data_name')?>">
        
                    <img src="<?php echo get_sub_field('portfolio_image')?>"alt="">
                    
                    <!-- overlay -->
                    <div class="portfolio__images__intro">
                        <h5><?php echo get_sub_field('portfolio_overlay_h5')?></h5>
                        <p><?php echo get_sub_field('portfolio_overlay_p')?></p>
                        <div class="portfolio__images__hashtags">
                            <h4><?php echo get_sub_field('portfolio_hashtag_1')?></h4>               
                            <h4><?php echo get_sub_field('portfolio_hashtag_2')?></h4>               
                            <h4><?php echo get_sub_field('portfolio_hashtag_3')?></h4>               
                            <h4><?php echo get_sub_field('portfolio_hashtag_4')?></h4>               
                        </div>
                        <div class="portfolio__images__view"> 
                            <i class="fa-regular <?php echo get_sub_field('portfolio_btn_icon')?>"></i>
                            <h4><?php echo get_sub_field('portfolio_btn_h4')?></h4>
                        </div>
                    </div>
                </div>
                <?php endwhile;
            else:
                echo "No more Images";
            endif;
            ?>
              </div>
                 </div>
            </div>
       </section>

        <!-- LOGO SLIDER STARTS -->
       <section class="logo__slider" data-aos="fade-up" data-aos-delay="100">
        <div class="container">
            <div class="logo__slider__wrapper">
                <!-- card1 -->

                <?php
            if(have_rows('logo_cards')) : ?>
            <?php while(have_rows('logo_cards')) : the_row(); ?>
                <div class="logo__cards">
                    <img src="<?php echo get_sub_field('logo_slider_images')?>" alt="">
                </div>
                <?php endwhile;
            else:
                echo "No more Logo Images";
            endif;
            ?>
            </div>
        </div>
       </section>
        <!-- LOGO SLIDER ENDS -->

   <!-- Pricing starts -->
   <section class="pricing">
    <div class="container">
        <div class="pricing__wrapper">
            <div class="pricing__title">
                <h4 data-aos="fade-up"><?php echo get_field('pricing_h4')?></h4>
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('pricing_h2')?></h2>
                <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('pricing_p')?></p>
            </div>
            <div class="pcard__wrapper">
                
                <!-- card 1 -->
                
                <?php
            if(have_rows('pricing_cards')) : ?>
            <?php while(have_rows('pricing_cards')) : the_row(); ?>
                <div data-aos="fade-up" data-aos-delay="200" class="pcard">
                    <div class="pcard__top">
                        <i class="fa-solid <?php echo get_sub_field('pricing_icon')?>"></i>
                        <h3><?php echo get_sub_field('pricing_h3')?></h3>
                        <h2><?php echo get_sub_field('pricing_h2')?></h2>
                        <p><?php echo get_sub_field('pricing_p')?></p>
                    </div>

                    <?php
                     if(have_rows('pricing_plan')) : ?>
                     <?php while(have_rows('pricing_plan')) : the_row(); ?>
                    <ul>
                        <li><i class="fa-regular <?php echo get_sub_field('pricing_icons')?>"></i> <?php echo get_sub_field('pricing_benefits')?></li>
                        <?php endwhile;
                    else:
                    echo "No more Logo Images";
                    endif;
                    ?> 
                    </ul>
                    
                    <div class="pcard__btn">
                        <a class="btn <?php echo get_sub_field('pricingbtn_color')?>" href=""><?php echo get_sub_field('pricing_btn')?></a>
                    </div>
                </div>
                <?php endwhile;
            else:
                echo "No more Logo Images";
            endif;
            ?> 
            </div>
        </div>
    </div>
</section>
<!-- Pricing ends -->

         <!-- TESTIMONIALS STARTS -->
       <section class="testimonials">
        <div class="container">
            <div class="testimonials__wrapper">
                <div class="testimonials__text">
                    <h4  data-aos="fade-up"><?php echo get_field('testimonial_h4')?></h4>
                    <h2  data-aos="fade-up" data-aos-delay="100"><?php echo get_field('testimonial_h2')?></h2>
                    <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('testimonial_p')?></p>
                </div>

                <div class="testimonials__slider pt-6" data-aos="fade-up" data-aos-delay="200">
                    

                <?php
                     if(have_rows('testimonial_cards')) : ?>
                     <?php while(have_rows('testimonial_cards')) : the_row(); ?>
                    <div>
                    <div class="testimonials__cards">

                    
                       <div class="testimonials__cards__profile">
                        <img src="<?php echo get_sub_field('testimonial_img')?>" alt="">
                        
                        <div>
                        <span class="testimonials__cards__profile__name"><?php echo get_sub_field('testimonial_span')?></span>
                        <?php 
                        if(have_rows('testimonial_star')) : ?>
                        <?php while(have_rows('testimonial_star')) : the_row(); ?>
                        <ul>
                            <li><i class="<?php echo get_sub_field('stars_style')?> <?php echo get_sub_field('stars_count')?>"></i></li>
                        <?php endwhile;
                        else:
                        echo "No more Logo Images";
                        endif;
                        ?> 
                        </ul>
                       </div>
                       </div>
                       <p><?php echo get_sub_field('testimonial_p')?></p>
                    </div>     
                </div>   
                <?php endwhile;
            else:
                echo "No more Logo Images";
            endif;
            ?>    
            </div>
        </div>
       </section>
        <!-- TESTIMONIALS END -->

   <!-- Team starts -->
   <section class="team">
    <div class="container">
        <div class="team__wrapper">
            <div class="team__title">
                <h4 data-aos="fade-up"><?php echo get_field('team_h4') ?></h4>
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('team_h2') ?></h2>
                <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('team_p') ?></p>
            </div>
            <div class="tcard__wrapper">
                <?php
                if(have_rows('team_card')) : ?>
                <?php while(have_rows('team_card')) : the_row(); ?>
                <!-- card 1 -->
                <div data-aos="fade-right" data-aos-delay="200" class="tcard">
                    <div>
                        <img src="<?php echo get_sub_field('team_image') ?>" alt="">
                    </div>
                    <div class="tcard__text">
                        <h3><?php echo get_sub_field('team_name') ?></h3>
                        <p><?php echo get_sub_field('team_role') ?></p>
                    </div>
                    <?php 
                    if(have_rows('team_social')) : ?>
                    <?php while(have_rows('team_social')) : the_row(); ?>
                    <ul>
                        <li><a href=""><i class="fa-brands <?php echo get_sub_field('team_icon') ?>"></i></a></li>
                        <?php endwhile;
                        else:
                        echo "No more Team Icon";
                        endif;
                        ?>       
                    </ul>
                </div>
                <?php endwhile;
                else:
                    echo "No more Team Card";
                endif;
                ?>    
            </div>
        </div>
    </div>
</section>
<!-- Team ends -->

    <!-- BLOG STARTS -->
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                <h4 data-aos="fade-up"><?php echo get_field('blog_h4') ?></h4>
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('blog_h2') ?></h2>
                <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('blog_p') ?></p>
            </div>
            
            <div class="card__wrapper2">
                <!-- card 1 -->
                <?php
                if(have_rows('blog_card')) : ?>
                <?php while(have_rows('blog_card')) : the_row(); ?>
                <div class="blog__card2">
                    <div>
                        <img src="<?php echo get_sub_field('blogcrd_image') ?>" alt="">
                    </div>
                    
                    
                    
                    <div class="blog__info">
                    <ul>
                    <?php
                    if(have_rows('blogcrd_info')) : ?>
                <?php while(have_rows('blogcrd_info')) : the_row(); ?>
                        <h3><span><i class="fa-solid <?php echo get_sub_field('info_icon') ?>"></i></span> <?php echo get_sub_field('info_h3') ?></h3>
                        <?php endwhile;
                else:
                    echo "No more Blog Icons";
                endif;
                ?>  
                    </ul>
                    </div>
                    
                   
                    <div class="card__text">
                        <h3><?php echo get_sub_field('blogcrd_h3') ?></h3>
                        <p><?php echo get_sub_field('blogcrd_p') ?></p>
                    </div>
                    <div class="card__btn">
                        <a href=""><?php echo get_sub_field('blogcrd_btn') ?> <span><i class="fa-solid <?php echo get_sub_field('blogcrd_icon') ?>"></i></span></a>
                    </div>
                </div>
                <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?>    
            </div>
            </div>
    </section>

    <!-- BLOG ENDS -->

<!-- FAQ STARTS -->
<section class="faq">
    <div class="container">
      <div class="faq__title">
        <h4 data-aos="fade-up"><?php echo get_field('faq_h4') ?></h4>
        <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('faq_h2') ?></h2>
        <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('faq_p') ?></p>
      </div>
      <div class="faq__wrapper">
        
        <div class="faq__image" data-aos="fade-right" data-aos-delay="200">
          <img src="<?php echo get_field('faq_img') ?>" alt="">
        </div>
        <div class="faq__question">
          <!-- question 1 -->
          
          <?php
          if(have_rows('faq_cards')) : ?>
                <?php while(have_rows('faq_cards')) : the_row(); ?>
          <div class="faq__cards" data-aos="fade-up" data-aos-delay="250">
            <div class="question">
              <h5><?php echo get_sub_field('faqs_question') ?><i class="fa-solid <?php echo get_sub_field('faq_icons') ?>"></i></h5>  
              <div class="contents">
                <p><?php echo get_sub_field('faqs_question_p') ?></p> 
              </div> 
            </div>
          </div>
          <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?>    
        </div>
      </div>
    </div>
   </section>
   <!-- FAQ ENDS -->


   <!-- CONTACTS STARTS -->
   <section class="contact">
    <div class="container">
            <div class="contact__title">
                <h4 data-aos="fade-up"><?php echo get_field('contacts_h4') ?></h4>
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo get_field('contacts_h2') ?></h2>
                <p data-aos="fade-up" data-aos-delay="150"><?php echo get_field('contacts_p') ?></p>
            </div>
        <div class="contact__wrapper">
            <div class="contact__left">
                <h3 data-aos="fade-right" data-aos-delay="200"><?php echo get_field('contacts_info_title') ?></h3>


                <ul>
                <?php
                    if(have_rows('contacts_info_data')) : ?>
                <?php while(have_rows('contacts_info_data')) : the_row(); ?>
                    <li class="flex gap-6" data-aos="fade-right" data-aos-delay="250">
                        <i class="<?php echo get_sub_field('contactsicon_style') ?> <?php echo get_sub_field('contacts_icon') ?>"></i>
                        <p><?php echo get_sub_field('contacts_info') ?></p>
                    </li>
                    <?php endwhile;
                else:
                    echo "No more Blog Card";
                endif;
                ?>    
                </ul>
            </div>
            <div class="contact__form">
                <ul>
                    <li data-aos="fade-right" data-aos-delay="200">
                        <input type="text" placeholder="Name">
                    </li>
                    <li data-aos="fade-left" data-aos-delay="200">
                        <input type="text" placeholder="Subject">
                    </li>
                </ul>
                <ul data-aos="fade-up" data-aos-delay="250">
                    <input type="text" placeholder="Email">
                </ul>
                <ul data-aos="fade-up" data-aos-delay="300">
                    <textarea name="" id="" cols="30" rows="10" placeholder="Message"></textarea>
                </ul>
                <div class="contact__btn" data-aos="fade-up" data-aos-delay="350">
                    <a class="btn bg--vera" href="">Send Now</a>
                </div>
            </div>
        </div>
    </div>
   </section>
   <!-- CONTACTS ENDS -->

        <!-- MAP STARTS -->
   <section class="map">
    <div class="container">
      <div class="map__wrapper">
        <iframe class="contact-map" data-aos="fade-up" data-aos-delay="450" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.9050207912896!2d-0.14675028449633118!3d51.514958479636384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761ad554c335c1%3A0xda2164b934c67c1a!2sOxford+St%2C+London%2C+UK!5e0!3m2!1sen!2sro!4v1485889312335" allowfullscreen=""></iframe>
      </div>  
    </div>
   </section>
   <!-- MAP ENDS -->

<?php get_footer(); ?>