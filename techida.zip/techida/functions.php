<?php
function techida_assets(){
    // wp_enqueue_style -> load your css assets 
    wp_enqueue_style('techida-style', get_template_directory_uri() . "/css/style.css", microtime());
    wp_enqueue_style('techida-icons', "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css", 1.0);
    wp_enqueue_style('techida-aos', "https://unpkg.com/aos@2.3.1/dist/aos.css", 1.0);
    wp_enqueue_style('techida-tns', "https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css", 1.0);
    wp_enqueue_style('techida-lineAwesome', "https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css", 1.0);
    wp_enqueue_style('techida-fontAwesome', "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css", 1.0);

    

    
    // wp_enqueue_script -> load your JS assets
    wp_enqueue_script('techida-slider-js', 'https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/min/tiny-slider.js', 1.0, [], true );
    wp_enqueue_script('techida-animation-js', 'https://unpkg.com/aos@2.3.1/dist/aos.js', 1.0, [], true );
    wp_enqueue_script('techida-script', get_template_directory_uri() . "/script/script.js", microtime(), [], true );
    wp_enqueue_script('techida-app', get_template_directory_uri() . "./script/particles.js", microtime(), [], true );
    wp_enqueue_script('techida-particle', get_template_directory_uri() . "./script/app.js", microtime(), [], true );
   
   // conditional loading of assets base on the current page
    // if(is_front_page()) {
    //     wp_enqueue_script('techida-slider', get_template_directory_uri() . "./script/slider.js", microtime(), [], true );
    // }
}
add_action('wp_enqueue_scripts', 'techida_assets');

function techida_support(){
    add_theme_support('post-thumbnails');
    add_theme_support('menus');

    register_nav_menu('header__menu', 'Header Menu');
    register_nav_menu('header__mobileMenu1', 'Header Mobile Menu1');
    register_nav_menu('header__mobileMenu2', 'Header Mobile Menu2');
    register_nav_menu('footer__menu', 'Footer Menu');
}

add_action('after_setup_theme', 'techida_support');
add_theme_support('custom-logo'); 

function experience_custom_post(){
    $experience_label = array(
        'name'     => __('Experiences', 'textdomain'),
        'singular_name' => __('Experience', 'textdomain'),
        'add_new'    => __('Add Experience', 'textdomain'),
        'edit_item'   => __('Edit Experience', 'textdomain'),
        'add_new_item' => __('Add New Experience', 'textdomain'),
        'all_items'   => __('Experiences', 'textdomain'),
    );

    $experience_args = array(
        'labels' => $experience_label,
        'public' => true,
        'capability_type' => 'post',
        'show_ui' => true,
        'taxonomies' => array('post_tag','category'),
        'supports' => array('title', 'editor')
    );

    register_post_type('experience', $experience_args);

}
        
add_action('init', 'experience_custom_post');